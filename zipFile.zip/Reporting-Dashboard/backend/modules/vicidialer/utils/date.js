export function fixDateFormat(dateStr) {
    return dateStr.replace(/ /g, "+");
}
